// Vercel serverless function entry point
const app = require('../server');

// Export as serverless function handler
module.exports = app;
